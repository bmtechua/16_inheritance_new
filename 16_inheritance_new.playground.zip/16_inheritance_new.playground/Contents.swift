import UIKit
import Foundation

//Перед історія:
//Прийшов до нас містер  Бібліотекар, і каже я хочу зробити інвентаризацію нашої бібліотечної колекції.
//У бібліотеції зберігаються книги, cd диски, журнали, платівки.
//Це все можна взяти на певний час у користування.
//
//
//Проблема:
//- Немає загального списку, що є у бібліотеці
//- Важко дізнатись, що є у бібліотеці, а що у використанні
//- Важко відслідковувати, хто читає книжку взяти у оренду, більше ніж 30 днів
//
//
//Тому необхідно розробити система, яка дозволить вести облік усіх медіа у бібліотеці
//
//
//Кожен з даних типів має характеризуватись: id, name, дата коли взято у користування, імя, адреса та телефон людини, яка взяла у користування; тип медії.
//Але крім цього книжка має мати інформацію про автора та рік видання; кількість сторінок, та коротких опис
//CD диск: ми повинні знати чи це копія чи оригінал, також формат інформації у ньому(кліпи, фільми, документальні серіали)
//Журнал: має мати дату випуску,
//Платівка: час програвання.
//
//
//Створити 2 книжки, 3 платівки, 4 журнали, 1 сд диск.
//
//
//Вивести інформацію про користувача, який орендує уже більше 30 днів;
//Вивести усі CDдиски з документальними фільмами.
//Вивести усі медія, які на даний момент є у бібліотеці.


    
   
    enum TypeOfMedia: String {
        case Book = "Book"
        case Record = "Record"
        case Cd = "CD"
        case Magazine = "Magazine"
    }

    enum Original: String {
        case Original = "Original"
        case Copy = "Copy"
    }

    enum TypeOfInfo: String {
        case clip = "Clip"
        case movie = "Movie"
        case documental = "Documental serial"
    }

    class Human {
        var name: String
        var address: String
        var phonenumber: Int

        init(name: String, address: String, phonenumber: Int) {
            self.name = name
            self.address = address
            self.phonenumber = phonenumber
        }


    class Media {
        var id: Int = 0
        var name: String
        var description: String?
        var dateOfTake: Date?
        var user: Human?

        init (name: String, description: String?, dateOfTake: Date?, user: Human?) {
        self.name = name
        self.description = description ?? "nil"
        self.dateOfTake = dateOfTake ?? nil
        self.user = user
    }
}
    
    class Book: Media {
        var nameAuthor: String
        var yearOfPrint: Int
        var quantityOfPages: Int
        var typeOfMedia: String = TypeOfMedia.Book.rawValue
        
        init (nameAuthor: String, yearOfPrint: Int, quantityOfPages: Int, name: String, description: String?, dateOfTake: Date?, user: Human?) {
            self.nameAuthor = nameAuthor
            self.yearOfPrint = yearOfPrint
            self.quantityOfPages = quantityOfPages
            super.init(name: name, description: description, dateOfTake: dateOfTake, user: user)
        }
    }
    
    class Cd: Media {
        var originalCD: Original
        var typeOfInfoCD: TypeOfInfo
        var typeOfMedia: String = TypeOfMedia.Cd.rawValue
        
            init(originalCD: Original, typeOfInfoCD: TypeOfInfo, name: String, description: String?, dateOfTake: Date?, user: Human?) {
                self.originalCD = originalCD
                self.typeOfInfoCD = typeOfInfoCD
                super.init(name: name, description: description, dateOfTake: dateOfTake, user: user)
            }
        }
    
    class Record: Media {
        var timePlay: Int
        var typeOfMedia: String = TypeOfMedia.Record.rawValue
        
        init(timePlay: Int, name: String, description: String?, dateOfTake: Date?, user: Library.Human?) {
            self.timePlay = timePlay
            super.init(name: name, description: description, dateOfTake: dateOfTake, user: user)
        }
    }
    
    class Magazine: Media {
        var dateOfPrint: String
        var typeOfMedia: String = TypeOfMedia.Magazine.rawValue
        
        init(dateOfPrint: String, name: String, description: String?, dateOfTake: Date?, user: Library.Human?) {
            self.dateOfPrint = dateOfPrint
            super.init(name: name, description: description, dateOfTake: dateOfTake, user: user)
        }
    }
    

}

class Library {
    var usersArray: [Library.Human] = []
    var itemsArray: [Library.Media] = []
    var idArray: [Int] = []
    var id = 0
    var date: (Int, Int, Int) = (0,0,0)
    
}

    func addArrayUser(user: Library.Human){
        if usersArray.contains(where: {$0.name == user.name}) && usersArray.contains(where: {$0.address == user.address}) && usersArray.contains(where: {$0.phonenumber == user.phonenumber})  {
            print("User with same name, address, phonenumber already exist. No possible appending to array!")
        } else {
            usersArray.append(user)
        }
    }

    func addArrayItems(item: Library.Media){
            id += 1
            idArray.append(id)
            itemsArray.append(item)
            item.id = idArray.last!

    }
    
    func lendMedia(_ user: Human,_ date: (Int, Int, Int), _ media: Media) {
        let calendar = Calendar.current
        var dateComponents = DateComponents()
        dateComponents.year = date.0
        dateComponents.month = date.1
        dateComponents.day = date.2
        let dateNow = calendar.date(from: dateComponents)
        media.user = user
        media.dateOfTake = dateNow
    }
    
    func separateCdDocumental(_ array: [Media]) {
        for i in 0..<array.count {
            if (array[i] as? Library.Cd)?.typeOfInfoCD == .documental {
                print("ID: \(library1.itemsArray[i].id), \(library1.itemsArray[i].name) is documental serial")
            }
        }
    }
    
    func controlPeriodLandingMedia() {
        
    }



var library1 = Library()
library1.usersArray
let user1 = Library.Human(name: "Ivanov", address: "Moscow", phonenumber: 123456)
let user2 = Library.Human(name: "Petrov", address: "Petergof", phonenumber: 123456)
let user3 = Library.Human(name: "Sidorov", address: "Kiyiv", phonenumber: 111111)

let book1 = Library.Book(nameAuthor: " Ivan Franko", yearOfPrint: 1979, quantityOfPages: 300, name: "Painted fox", description: "qwerty", dateOfTake: nil, user: user1)
let book2 = Library.Book(nameAuthor: "Taras Shevchenko", yearOfPrint: 1993, quantityOfPages: 100, name: "13", description: "nil", dateOfTake: nil, user: nil)
let cd1 = Library.Cd(originalCD: .Copy, typeOfInfoCD: .movie, name: "Invisible Man", description: "Movie about adventures of man", dateOfTake: nil, user: nil)
let cd2 = Library.Cd(originalCD: .Copy, typeOfInfoCD: .documental, name: "Sun", description: "Movie about star", dateOfTake: nil, user: nil)
let cd3 = Library.Cd(originalCD: .Original, typeOfInfoCD: .documental, name: "Moon", description: "Movie about Earth's moon", dateOfTake: nil, user: nil)
let record1 = Library.Record(timePlay: 54, name: "Beatles", description: "Ballads", dateOfTake: nil, user: nil)
let record2 = Library.Record(timePlay: 34, name: "Mozart", description: "Simphonies", dateOfTake: nil, user: nil)
let record3 = Library.Record(timePlay: 40, name: "Bohnie M", description: "Daddy", dateOfTake: nil, user: nil)
let magazine1 = Library.Magazine(dateOfPrint: "9/2021", name: "National Geographique", description: "Magazine about naturals, technique and world", dateOfTake: nil, user: nil)
let magazine2 = Library.Magazine(dateOfPrint: "10/2021", name: "National Geographique", description: "Magazine about naturals, technique and world", dateOfTake: nil, user: nil)
let magazine3 = Library.Magazine(dateOfPrint: "11/2021", name: "National Geographique", description: "Magazine about naturals, technique and world", dateOfTake: nil, user: nil)
let magazine4 = Library.Magazine(dateOfPrint: "12/2021", name: "National Geographique", description: "Magazine about naturals, technique and world", dateOfTake: nil, user: nil)




library1.addArrayUser(user: user1)
library1.addArrayUser(user: user2)
library1.addArrayUser(user: user3)

library1.addArrayItems(item: book1)
library1.addArrayItems(item: book2)
library1.addArrayItems(item: cd1)
library1.addArrayItems(item: cd2)
library1.addArrayItems(item: cd3)
library1.addArrayItems(item: record1)
library1.addArrayItems(item: record2)
library1.addArrayItems(item: record3)
library1.addArrayItems(item: magazine1)
library1.addArrayItems(item: magazine2)
library1.addArrayItems(item: magazine3)
library1.addArrayItems(item: magazine4)

library1.id

library1.usersArray
library1.itemsArray

library1.lendMedia(user1, (2020, 04, 15), book1)
library1.lendMedia(user2, (2021, 05, 20), cd3)
library1.itemsArray[0].dateOfTake
library1.itemsArray[4].dateOfTake

library1.separateCdDocumental(library1.itemsArray)


//for i in 0..<library1.itemsArray.count {
//    if (library1.itemsArray[i] as? Library.Cd)?.typeOfInfoCD == .documental {
//        print("\(library1.itemsArray[i].name) - docum")
//    }
//}


let wert = library1.usersArray.contains(where: {$0.name == user1.name})


